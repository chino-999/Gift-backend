# Nuvora database (Supabase)

There is no server to run. Supabase provides the database, the accounts, and the photo storage, and the
rules that protect everything live inside the database itself (`migrations/001_initial_schema.sql`).

| Part | What it does |
|---|---|
| **Auth** | Email and password accounts for senders. Receivers never have accounts |
| **Tables** | `gifts`, `gift_images`, `receiver_submissions`, plus `request_log` (internal, for rate limits) |
| **Functions** | `get_public_gift`, `record_visit`, `submit_receiver_details`: the only things a receiver can call |
| **Storage** | Public bucket `gift-photos` (JPEG, PNG, WebP, 5 MB max) |

## Already set up in your project (`grsiyvnytubabtjanmfq`)

- The schema in `migrations/001_initial_schema.sql` is applied, and the `gift-photos` bucket exists.
- All four tables have row-level security on.

## One setting only you can change

In the Supabase dashboard: **Authentication, then Sign In / Providers, then Email**.
- Turn **off "Confirm email"** so new senders can use the site straight after signing up. If you leave it on, sign-up
  shows "Check your email to confirm your account", and Supabase's built-in email sender allows only a few emails an hour.
- Optional: raise **Minimum password length** to 8. The site already asks for 8, but the server's own minimum is 6 until you change it.

## Opening your records

You (the project owner) open everything in the dashboard: **Table Editor**, then `gifts` or `receiver_submissions`.
That is the only place the card details can be read. Senders can't read them, even for their own gifts.

## Where each rule is enforced

| Rule | Enforced by |
|---|---|
| A sender sees and changes only their own gifts, photos and submissions | Row-level security |
| A sender can never change visit counts, the public link, the owner, or the first-submission time | Column permissions |
| A published gift needs a message and at least one photo; it can't go back to draft | Database trigger `gifts_guard` |
| After the first submission the gift is locked (text, photos, and photo files) | Trigger plus row-level security plus storage policy |
| Archiving keeps the gift, photos and submissions; the link stops working at once | Trigger plus the public functions |
| A gift with submissions can't be deleted | Foreign key `on delete restrict` |
| Max 10 photos per gift; a published gift keeps one | Trigger `gift_images_guard` |
| Card details are invisible to senders | Column permissions on `receiver_submissions` |
| Receivers see only title, description, message, sender name and photos of **active** gifts | `get_public_gift` |
| Visits: counted once per address per gift per 30 minutes; robots ignored | `record_visit` |
| Submissions: required fields checked, duplicates ignored by `submission_key`, 10 attempts per hour per address | `submit_receiver_details` |
| Senders upload only into their own folder (`<user id>/...`) | Storage policy |

## Changing the database later

Add a new numbered file in `migrations/` (for example `002_...sql`) and run it in the dashboard's SQL Editor.
Don't edit `001`.

## Known limits (honest list)

- **Photo content check:** the browser checks each photo's real file type before upload, and the bucket only accepts
  JPEG/PNG/WebP up to 5 MB. Supabase checks the declared type, not the file's contents, so a determined sender
  could upload a mislabelled file into their own folder.
- **Photo files stay reachable:** the bucket is public, so a photo's exact address keeps working even after its gift
  is archived. The gift page and data stop being served immediately.
- **Rate limits** use the address Supabase passes along (`x-forwarded-for`). They are per address, not per person.
- **Session:** the signed-in session is kept in the browser's local storage, which is how Supabase's own library works too.
