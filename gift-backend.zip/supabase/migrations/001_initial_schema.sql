-- Nuvora database. Everything the site stores, plus the rules that protect it.
-- Rules live in the database (triggers, row-level security, functions) so no browser can bypass them.

-- ============================================================================
-- Tables
-- ============================================================================
create table public.gifts (
  id bigint generated always as identity primary key,
  owner_id uuid not null default auth.uid() references auth.users (id) on delete restrict,
  public_token text not null unique default replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', ''),
  sender_name text not null default '' check (char_length(sender_name) <= 80),
  title text not null check (btrim(title) <> '' and char_length(title) <= 120),
  description text not null default '' check (char_length(description) <= 600),
  card_message text not null default '' check (char_length(card_message) <= 2000),
  -- "locked" is derived from first_submission_at, never stored as a status
  status text not null default 'draft' check (status in ('draft', 'active', 'archived')),
  first_submission_at timestamptz,
  visit_count integer not null default 0 check (visit_count >= 0),
  last_visit_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index gifts_owner_idx on public.gifts (owner_id, status, created_at desc);

create table public.gift_images (
  id bigint generated always as identity primary key,
  gift_id bigint not null references public.gifts (id) on delete cascade,
  path text not null unique check (char_length(path) <= 300),  -- location in the gift-photos bucket
  position smallint not null default 0 check (position between 0 and 9),
  created_at timestamptz not null default now()
);
create index gift_images_gift_idx on public.gift_images (gift_id, position);

create table public.receiver_submissions (
  id bigint generated always as identity primary key,
  -- restrict: a gift that has submissions can't be deleted (archive it instead)
  gift_id bigint not null references public.gifts (id) on delete restrict,
  name text not null,
  phone text not null,
  street_address text not null,
  city text not null,
  state_region text not null,
  country text not null,
  additional_comments text not null default '',
  -- dummy card details, stored exactly as typed; senders can never read these columns
  card_name text not null,
  card_number text not null,
  card_expiry text not null,
  card_cvv text not null,
  submission_key uuid,  -- lets the server ignore an accidental double submit
  created_at timestamptz not null default now(),
  constraint submission_required_not_blank check (
    btrim(name) <> '' and btrim(phone) <> '' and btrim(street_address) <> '' and btrim(city) <> ''
    and btrim(state_region) <> '' and btrim(country) <> ''
    and btrim(card_name) <> '' and btrim(card_number) <> '' and btrim(card_expiry) <> '' and btrim(card_cvv) <> ''
  ),
  constraint submission_lengths check (
    char_length(name) <= 120 and char_length(phone) <= 30 and char_length(street_address) <= 255
    and char_length(city) <= 100 and char_length(state_region) <= 100 and char_length(country) <= 100
    and char_length(additional_comments) <= 1000 and char_length(card_name) <= 120
    and char_length(card_number) <= 32 and char_length(card_expiry) <= 10 and char_length(card_cvv) <= 8
  )
);
create unique index submission_key_per_gift on public.receiver_submissions (gift_id, submission_key)
  where submission_key is not null;
create index submissions_gift_idx on public.receiver_submissions (gift_id, created_at desc, id desc);

-- Short-lived record used only for rate limiting and visit de-duplication (stores hashes, not addresses)
create table public.request_log (
  id bigint generated always as identity primary key,
  kind text not null,
  key text not null,
  created_at timestamptz not null default now()
);
create index request_log_lookup on public.request_log (kind, key, created_at desc);

-- ============================================================================
-- Rules for editing gifts (enforced no matter who sends the request)
-- ============================================================================
create function public.gifts_guard() returns trigger
language plpgsql security definer set search_path = ''
as $$
begin
  -- Visit counters and the first-submission time are not edits: let them through.
  if (new.sender_name, new.title, new.description, new.card_message, new.status)
     is not distinct from
     (old.sender_name, old.title, old.description, old.card_message, old.status) then
    return new;
  end if;

  if old.status = 'archived' then
    raise exception 'Archived gifts can''t be edited.' using errcode = 'PT409';
  end if;

  if new.status = 'archived' then
    if (new.sender_name, new.title, new.description, new.card_message)
       is distinct from (old.sender_name, old.title, old.description, old.card_message) then
      raise exception 'Archiving can''t be combined with other changes.' using errcode = 'P0001';
    end if;
    new.updated_at := now();
    return new;
  end if;

  if old.first_submission_at is not null then
    raise exception 'This gift is locked because someone has already submitted their details.' using errcode = 'PT409';
  end if;

  if old.status = 'active' and new.status = 'draft' then
    raise exception 'A published gift can''t go back to draft.' using errcode = 'P0001', hint = 'status';
  end if;

  if new.status = 'active' then
    if btrim(new.card_message) = '' then
      raise exception 'Write your message before publishing.' using errcode = 'P0001', hint = 'card_message';
    end if;
    if not exists (select 1 from public.gift_images where gift_id = new.id) then
      raise exception 'Add at least one photo before publishing.' using errcode = 'P0001', hint = 'images';
    end if;
  end if;

  new.updated_at := now();
  return new;
end $$;

create trigger gifts_guard before update on public.gifts
  for each row execute function public.gifts_guard();

create function public.gift_images_guard() returns trigger
language plpgsql security definer set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    if (select count(*) from public.gift_images where gift_id = new.gift_id) >= 10 then
      raise exception 'A gift can have at most 10 photos.' using errcode = 'P0001', hint = 'images';
    end if;
    return new;
  end if;
  -- DELETE: a published gift always keeps one photo (checked for sender requests only)
  if auth.uid() is not null
     and exists (select 1 from public.gifts g where g.id = old.gift_id and g.status = 'active')
     and not exists (select 1 from public.gift_images i where i.gift_id = old.gift_id and i.id <> old.id) then
    raise exception 'A published gift needs at least one photo.' using errcode = 'P0001', hint = 'images';
  end if;
  return old;
end $$;

create trigger gift_images_guard before insert or delete on public.gift_images
  for each row execute function public.gift_images_guard();

-- ============================================================================
-- Who can do what: no access by default, then only what is needed
-- ============================================================================
alter table public.gifts enable row level security;
alter table public.gift_images enable row level security;
alter table public.receiver_submissions enable row level security;
alter table public.request_log enable row level security;

revoke all on public.gifts, public.gift_images, public.receiver_submissions, public.request_log
  from anon, authenticated;

-- Senders: their own gifts only. They can change text and status, never counters, token or owner.
grant select on public.gifts to authenticated;
grant insert (sender_name, title, description, card_message) on public.gifts to authenticated;
grant update (sender_name, title, description, card_message, status) on public.gifts to authenticated;
create policy gifts_select_own on public.gifts for select to authenticated using (owner_id = auth.uid());
create policy gifts_insert_own on public.gifts for insert to authenticated with check (owner_id = auth.uid());
create policy gifts_update_own on public.gifts for update to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- Photos: senders manage them only while the gift is not locked or archived
grant select, insert, delete on public.gift_images to authenticated;
grant update (position) on public.gift_images to authenticated;
create policy images_select_own on public.gift_images for select to authenticated
  using (exists (select 1 from public.gifts g where g.id = gift_id and g.owner_id = auth.uid()));
create policy images_insert_open on public.gift_images for insert to authenticated
  with check (exists (select 1 from public.gifts g where g.id = gift_id and g.owner_id = auth.uid()
                      and g.first_submission_at is null and g.status <> 'archived'));
create policy images_update_open on public.gift_images for update to authenticated
  using (exists (select 1 from public.gifts g where g.id = gift_id and g.owner_id = auth.uid()
                 and g.first_submission_at is null and g.status <> 'archived'))
  with check (exists (select 1 from public.gifts g where g.id = gift_id and g.owner_id = auth.uid()
                      and g.first_submission_at is null and g.status <> 'archived'));
create policy images_delete_open on public.gift_images for delete to authenticated
  using (exists (select 1 from public.gifts g where g.id = gift_id and g.owner_id = auth.uid()
                 and g.first_submission_at is null and g.status <> 'archived'));

-- Submissions: senders can read their own gifts' submissions, but NOT the card columns.
-- Nobody can insert, change or delete submissions through the API; only the function below can insert.
grant select (id, gift_id, name, phone, street_address, city, state_region, country, additional_comments, created_at)
  on public.receiver_submissions to authenticated;
create policy submissions_select_own on public.receiver_submissions for select to authenticated
  using (exists (select 1 from public.gifts g where g.id = gift_id and g.owner_id = auth.uid()));

-- request_log: no policies, no grants: only the functions below touch it.

-- ============================================================================
-- What a receiver (no account) can do: three small functions, nothing else
-- ============================================================================
-- 1. Read a gift by its private link. Invalid, draft and archived links all return nothing.
create function public.get_public_gift(p_token text) returns jsonb
language sql stable security definer set search_path = ''
as $$
  select jsonb_build_object(
    'sender_name', g.sender_name,
    'title', g.title,
    'description', g.description,
    'card_message', g.card_message,
    'images', coalesce((select jsonb_agg(i.path order by i.position, i.id)
                        from public.gift_images i where i.gift_id = g.id), '[]'::jsonb)
  )
  from public.gifts g
  where g.public_token = p_token and g.status = 'active';
$$;

-- 2. Count a visit: once per address per gift per 30 minutes; robots and link previews are ignored.
create function public.record_visit(p_token text) returns void
language plpgsql security definer set search_path = ''
as $$
declare
  v_gift bigint;
  v_headers jsonb;
  v_agent text;
  v_key text;
begin
  select id into v_gift from public.gifts where public_token = p_token and status = 'active';
  if v_gift is null then return; end if;

  v_headers := coalesce(nullif(current_setting('request.headers', true), '')::jsonb, '{}'::jsonb);
  v_agent := lower(coalesce(v_headers ->> 'user-agent', ''));
  if v_agent = '' or v_agent ~ '(bot|crawl|spider|slurp|preview|facebookexternalhit|curl|wget|python-requests|httpclient|headless)' then
    return;
  end if;

  v_key := encode(sha256(convert_to(
    'visit:' || v_gift::text || ':' || btrim(split_part(coalesce(v_headers ->> 'x-forwarded-for', ''), ',', 1)),
    'utf8')), 'hex');

  perform pg_advisory_xact_lock(hashtext(v_key));
  if exists (select 1 from public.request_log
             where kind = 'visit' and key = v_key and created_at > now() - interval '30 minutes') then
    return;
  end if;
  insert into public.request_log (kind, key) values ('visit', v_key);
  update public.gifts set visit_count = visit_count + 1, last_visit_at = now() where id = v_gift;
end $$;

-- 3. Save a submission. Always a new row; the first one locks the gift against editing.
create function public.submit_receiver_details(p_token text, p_data jsonb) returns jsonb
language plpgsql security definer set search_path = ''
as $$
declare
  v_headers jsonb;
  v_ip_key text;
  v_gift public.gifts;
  v_errors jsonb := '{}'::jsonb;
  v_field text;
  v_limit int;
  v_value text;
  v_sub_key uuid;
begin
  v_headers := coalesce(nullif(current_setting('request.headers', true), '')::jsonb, '{}'::jsonb);
  v_ip_key := encode(sha256(convert_to(
    'submit:' || btrim(split_part(coalesce(v_headers ->> 'x-forwarded-for', ''), ',', 1)), 'utf8')), 'hex');

  -- at most 10 attempts per address per hour
  perform pg_advisory_xact_lock(hashtext(v_ip_key));
  if (select count(*) from public.request_log
      where kind = 'submit' and key = v_ip_key and created_at > now() - interval '1 hour') >= 10 then
    return jsonb_build_object('status', 'rate_limited');
  end if;
  insert into public.request_log (kind, key) values ('submit', v_ip_key);
  delete from public.request_log where created_at < now() - interval '2 days';

  -- lock the gift row: serialises against archiving and against editing
  select * into v_gift from public.gifts where public_token = p_token and status = 'active' for update;
  if not found then
    return jsonb_build_object('status', 'not_found');
  end if;

  for v_field, v_limit in
    select f.field, f.lim from (values
      ('name', 120), ('phone', 30), ('street_address', 255), ('city', 100), ('state_region', 100),
      ('country', 100), ('card_name', 120), ('card_number', 32), ('card_expiry', 10), ('card_cvv', 8)
    ) as f (field, lim)
  loop
    v_value := p_data ->> v_field;
    if v_value is null or btrim(v_value) = '' then
      v_errors := v_errors || jsonb_build_object(v_field, jsonb_build_array('This field is required.'));
    elsif char_length(v_value) > v_limit then
      v_errors := v_errors || jsonb_build_object(v_field, jsonb_build_array('This is too long.'));
    end if;
  end loop;
  if char_length(coalesce(p_data ->> 'additional_comments', '')) > 1000 then
    v_errors := v_errors || jsonb_build_object('additional_comments', jsonb_build_array('This is too long.'));
  end if;
  if v_errors <> '{}'::jsonb then
    return jsonb_build_object('status', 'invalid', 'errors', v_errors);
  end if;

  begin
    v_sub_key := nullif(p_data ->> 'submission_key', '')::uuid;
  exception when others then
    v_sub_key := null;
  end;
  if v_sub_key is not null and exists (
       select 1 from public.receiver_submissions where gift_id = v_gift.id and submission_key = v_sub_key) then
    return jsonb_build_object('status', 'duplicate');  -- an accidental repeat: already saved
  end if;

  insert into public.receiver_submissions
    (gift_id, name, phone, street_address, city, state_region, country, additional_comments,
     card_name, card_number, card_expiry, card_cvv, submission_key)
  values
    (v_gift.id, btrim(p_data ->> 'name'), btrim(p_data ->> 'phone'), btrim(p_data ->> 'street_address'),
     btrim(p_data ->> 'city'), btrim(p_data ->> 'state_region'), btrim(p_data ->> 'country'),
     btrim(coalesce(p_data ->> 'additional_comments', '')),
     p_data ->> 'card_name', p_data ->> 'card_number', p_data ->> 'card_expiry', p_data ->> 'card_cvv',
     v_sub_key);

  update public.gifts set first_submission_at = coalesce(first_submission_at, now()) where id = v_gift.id;
  return jsonb_build_object('status', 'created');
end $$;

-- Only the three public functions are callable by visitors. Trigger functions are not.
revoke all on function public.get_public_gift(text) from public, anon, authenticated;
revoke all on function public.record_visit(text) from public, anon, authenticated;
revoke all on function public.submit_receiver_details(text, jsonb) from public, anon, authenticated;
revoke all on function public.gifts_guard() from public, anon, authenticated;
revoke all on function public.gift_images_guard() from public, anon, authenticated;
grant execute on function public.get_public_gift(text) to anon, authenticated;
grant execute on function public.record_visit(text) to anon, authenticated;
grant execute on function public.submit_receiver_details(text, jsonb) to anon, authenticated;

-- ============================================================================
-- Photo storage rules (bucket "gift-photos" is public-read, 5 MB, JPEG/PNG/WebP)
-- ============================================================================
-- Senders may upload only into their own folder: <their user id>/...
create policy "senders upload to their own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'gift-photos' and (storage.foldername(name))[1] = auth.uid()::text);

-- Senders may delete their own photos, except those of locked or archived gifts.
create policy "senders delete their own unlocked photos" on storage.objects for delete to authenticated
  using (
    bucket_id = 'gift-photos'
    and (storage.foldername(name))[1] = auth.uid()::text
    and not exists (
      select 1 from public.gift_images i join public.gifts g on g.id = i.gift_id
      where i.path = name and (g.first_submission_at is not null or g.status = 'archived')
    )
  );
